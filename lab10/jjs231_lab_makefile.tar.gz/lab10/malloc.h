//replace malloc here with the appropriate version of mymalloc
#define MALLOC malloc
//replace free here with the appropriate version of myfree
#define FREE free
//define DUMP_HEAP() to be the dump_heap() function that you write
#define DUMP_HEAP()
